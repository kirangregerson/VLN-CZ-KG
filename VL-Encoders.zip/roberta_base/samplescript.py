from transformers import pipeline

unmasker = pipeline('fill-mask', model='roberta-base')
print(unmasker("Good things come to those who <mask>."))
